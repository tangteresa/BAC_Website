<?php 
require_once('submit.php'); 

$db = new Database();
$ids = $db->ids(); 

echo $ids; 
?>