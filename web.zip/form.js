$(document).ready(function () {
  var valid = true;

  $("#adoptForm").hide();
  $("#otherForm").hide();

  $("input[type=radio]").on('change', function () {
    var reason = $('input[type=radio]:checked', '#Form').val();

    if (reason == "A") {
      $("#otherForm").hide();
      $("#adoptForm").show();
    } else if (reason == "O") {
      $("#adoptForm").hide();
      $("#otherForm").show();
    }
  });

  function required(item, idx) {
    if ($("#" + item).val() == "") {
      valid = valid && false;
      window.alert("missing");
    }
  }

  // Check required items for adopt vs other form type 
  $("#Form").on("submit", function () {
    window.alert("submit");
    valid = true;
    var form_type = $('input[type=radio]:checked', '#Form').val();
    var adopt = ["catid", "date1", "date2", "time1", "time2"];

    if (form_type == "A") {
      window.alert("adopt");
      adopt.forEach(required);
      return valid;
    } else if (form_type == "O") {
      window.alert("other");
      required("otherDescr", 0);
      return valid;
    }
  })
});