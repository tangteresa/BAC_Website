class Filler {
  constructor() {
    this.fill = false;
    this.formFields = {};
    this.formVals = {};
  }

  toggleFill() {
    this.fill = !this.fill;
  }

  /* values must be JSON encoded string */
  setForm(fields, values) {
    this.formVals = JSON.parse(values);
    this.formFields = fields;
    this.toggleFill();
  }

  fill() {
    if (this.fill) {
      for (i = 0; i < Array.length(this.formFields); i++) {
        var formField = this.formFields[i];
        $("#" + formField).val(this.formVals(formField));
      }

      this.toggleFill();
      this.formVals = {};
      this.formFields = {};
    }
  }

}

var filler = Filler(); 