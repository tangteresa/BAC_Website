$(document).ready(function () {
  var is_down = [];
  var highest = 6;

  for (i = 1; i <= highest; i++) {
    is_down.push(false);
    $("#d" + i).hide();
  }

  $(".drop").click(function () {
    var num = $(this).attr('id');
    toggleDrop(num);
  });

  /*function toggleDrop(num) {
    $("#d" + num).toggle();

    if ($("#d" + num).is(":visible")) {
      $("#" + num).html("About me <br> &#9650;");
    } else {
      $("#" + num).html("About me <br> &#9660;");
    }
  }*/

  function toggleDrop(num) {
    //$("#d" + num).toggle();
    if (is_down[num]) {
      up(num);
    } else {
      drop(num);
    }
  }

  function drop(num) {
    is_down[num] = true;
    $("#d" + num).show()
    $("#d" + num).css('animation-name', 'drop');
    $("#d" + num).on('animationend', function () {
      $("#" + num).html("About me <br> &#9650;");
    })
  }

  function up(num) {
    is_down[num] = false;
    $("#d" + num).css('animation-direction', 'reverse');
    $("#d" + num).on('animationend', function () {
      $("#d" + num).hide()
      $("#d" + num).css('animation-name', 'none');
      $("#" + num).html("About me <br> &#9660;");
    });
  }

});